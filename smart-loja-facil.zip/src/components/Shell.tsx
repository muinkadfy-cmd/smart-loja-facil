import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AppIcon } from './AppIcon';
import { buildAppAlerts } from '../lib/alerts';
import { api } from '../lib/api';
import { playOperationSound } from '../lib/sound';
import { getRuntimeInfo } from '../lib/runtime';
import type { DelphiIconName } from '../lib/icons';
import type { AppStatus, CreditSummary, PageKey, Product, Settings } from '../types';

const pages: Array<{ key: PageKey; label: string; icon: DelphiIconName }> = [
  { key: 'dashboard', label: 'Dashboard', icon: 'painel_da_loja' },
  { key: 'products', label: 'Produtos', icon: 'produtos' },
  { key: 'customers', label: 'Clientes', icon: 'clientes' },
  { key: 'orders', label: 'Pedidos', icon: 'pedidos' },
  { key: 'sales', label: 'Vendas / PDV', icon: 'vendas_pdv' },
  { key: 'cash', label: 'Caixa', icon: 'caixa' },
  { key: 'credits', label: 'Crediario', icon: 'crediario' },
  { key: 'receipts', label: 'Comprovantes', icon: 'comprovantes' },
  { key: 'reports', label: 'Relatorios', icon: 'relatorios' },
  { key: 'backup', label: 'Backup', icon: 'backup' },
  { key: 'settings', label: 'Configuracoes', icon: 'configuracoes' },
  { key: 'audit', label: 'Logs / Diagnostico', icon: 'auditoria_logs' },
  { key: 'diagnostics', label: 'Diagnostico Web', icon: 'bloqueio_seguro' },
];

const mobileMainPages: Array<{ key: PageKey; label: string; icon: DelphiIconName }> = [
  { key: 'dashboard', label: 'Inicio', icon: 'painel_da_loja' },
  { key: 'products', label: 'Produtos', icon: 'produtos' },
  { key: 'sales', label: 'Vendas', icon: 'vendas_pdv' },
  { key: 'customers', label: 'Clientes', icon: 'clientes' },
];

const headerActions: Array<{ key: string; label: string; mobileLabel: string; icon: DelphiIconName; action: 'refresh' | PageKey }> = [
  { key: 'refresh', label: 'Atualizar dados', mobileLabel: 'Atualizar', icon: 'atualizar', action: 'refresh' },
  { key: 'customers', label: 'Clientes', mobileLabel: 'Clientes', icon: 'clientes', action: 'customers' },
  { key: 'products', label: 'Produtos', mobileLabel: 'Produtos', icon: 'produtos', action: 'products' },
  { key: 'settings', label: 'Config. loja', mobileLabel: 'Config.', icon: 'configuracoes', action: 'settings' },
  { key: 'diagnostics', label: 'Diagnostico', mobileLabel: 'Status', icon: 'bloqueio_seguro', action: 'diagnostics' },
];

interface ShellProps {
  activePage: PageKey;
  setActivePage: (page: PageKey) => void;
  status: AppStatus | null;
  settings: Settings | null;
  children: React.ReactNode;
  onRefresh: () => void;
  refreshToken: number;
}

interface NavAlertMeta {
  count: number;
  level: 'danger' | 'warning' | 'info' | 'ok' | null;
}

function shortDbName(value: string | undefined): string {
  if (!value) return 'Banco local';
  return value.split(/[/\\]/).pop() || value;
}

function formatClassicDate(): string {
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date());
}

function pageSubtitle(page: PageKey): string {
  const subtitles: Record<PageKey, string> = {
    dashboard: 'Visao geral com atalhos, indicadores e status da loja online.',
    products: 'Gerencie catalogo, estoque e disponibilidade dos produtos.',
    customers: 'Cadastre, localize e acompanhe seus clientes com rapidez.',
    orders: 'Acompanhe pedidos locais e entregas sem perder o fluxo.',
    sales: 'Realize vendas, PDV e recebimentos com operacao simples.',
    cash: 'Controle entradas, saidas e fechamento do caixa.',
    credits: 'Consulte o crediario, parcelas e recebimentos pendentes.',
    receipts: 'Abra, imprima e reenvie comprovantes salvos.',
    reports: 'Veja metricas, exporte relatorios e acompanhe resultados.',
    backup: 'Proteja seus dados com backup e restauracao local.',
    settings: 'Ajuste a loja, preferencias e configuracoes do sistema.',
    audit: 'Consulte alertas, trilhas de auditoria e diagnosticos.',
    diagnostics: 'Confira conexao, login, permissao, cache e sincronizacao.',
  };
  return subtitles[page];
}

function initialsFromSettings(settings: Settings | null): string {
  const base = settings?.owner_name?.trim() || 'Administrador';
  const parts = base.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] || ''}${parts[1][0] || ''}`.toUpperCase();
}

export function Shell({ activePage, setActivePage, status, settings, children, onRefresh, refreshToken }: ShellProps): JSX.Element {
  const runtimeInfo = useMemo(() => getRuntimeInfo(), []);
  const [products, setProducts] = useState<Product[]>([]);
  const [credits, setCredits] = useState<CreditSummary[]>([]);
  const [toast, setToast] = useState<{ title: string; detail: string; page: PageKey; level: 'danger' | 'warning' | 'info' } | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const prevAlertSignature = useRef('');

  useEffect(() => {
    if (runtimeInfo.isWeb) {
      setProducts([]);
      setCredits([]);
      return undefined;
    }

    let alive = true;
    Promise.all([api.products(), api.credits()])
      .then(([nextProducts, nextCredits]) => {
        if (!alive) return;
        setProducts(nextProducts);
        setCredits(nextCredits);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [refreshToken, runtimeInfo.isWeb]);

  useEffect(() => {
    setSidebarOpen(false);
  }, [activePage]);

  const alerts = useMemo(() => buildAppAlerts(status, products, credits), [credits, products, status]);

  const navAlerts = useMemo<Record<PageKey, NavAlertMeta>>(() => {
    const result = pages.reduce((acc, page) => {
      acc[page.key] = { count: 0, level: null };
      return acc;
    }, {} as Record<PageKey, NavAlertMeta>);

    const weight: Record<'danger' | 'warning' | 'info' | 'ok', number> = {
      danger: 4,
      warning: 3,
      info: 2,
      ok: 1,
    };

    for (const alert of alerts) {
      if (alert.level === 'ok') continue;
      const current = result[alert.page];
      current.count += 1;
      if (!current.level || weight[alert.level] > weight[current.level]) current.level = alert.level;
    }

    return result;
  }, [alerts]);

  const activeAlerts = alerts.filter((alert) => alert.page === activePage && alert.level !== 'ok');
  const notificationCount = alerts.filter((alert) => alert.level !== 'ok').length;
  const activePageMeta = useMemo(() => pages.find((page) => page.key === activePage) ?? pages[0], [activePage]);
  const environmentLabel = runtimeInfo.isWeb ? 'Online' : status?.offline_ready ? 'Local / Offline' : 'Verificando';
  const storageLabel = runtimeInfo.storageLabel;
  const avatarInitials = initialsFromSettings(settings);

  useEffect(() => {
    const mainAlerts = alerts.filter((alert) => alert.level !== 'ok');
    const signature = mainAlerts.map((alert) => `${alert.id}:${alert.title}:${alert.detail}`).join('|');
    if (!signature) {
      prevAlertSignature.current = '';
      return;
    }
    if (signature !== prevAlertSignature.current) {
      const incoming = mainAlerts[0];
      setToast({ title: incoming.title, detail: incoming.detail, page: incoming.page, level: incoming.level as 'danger' | 'warning' | 'info' });
      playOperationSound(incoming.level === 'danger' ? 'error' : 'warning');
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Alerta da loja', { body: `${incoming.title} - ${incoming.detail}` });
      }
      prevAlertSignature.current = signature;
    }
  }, [alerts]);

  useEffect(() => {
    if (!toast) return undefined;
    const timer = window.setTimeout(() => setToast(null), 5200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const isMoreActive = !mobileMainPages.some((page) => page.key === activePage);

  return (
    <div className={`neo-shell ${runtimeInfo.isWeb ? 'neo-shell-web' : 'neo-shell-local'} ${sidebarOpen ? 'neo-nav-open' : ''}`}>
      <div className="neo-windowbar">
        <div className="neo-windowbar-brand">
          <AppIcon name="app_logo_cadeado_carrinho" size={16} className="neo-windowbar-icon" />
          <strong>Smart Loja Facil</strong>
        </div>
        <div className="neo-windowbar-right">
          <span>{runtimeInfo.isWeb ? 'PWA/Web' : 'Aplicativo local'}</span>
          <span>{runtimeInfo.isWeb ? 'Dados na nuvem' : shortDbName(status?.db_path)}</span>
        </div>
      </div>

      <div className="neo-layout">
        {sidebarOpen && <button type="button" className="neo-sidebar-backdrop" onClick={() => setSidebarOpen(false)} aria-label="Fechar menu" />}

        <aside className={`neo-sidebar ${sidebarOpen ? 'open' : ''}`}>
          <div className="neo-sidebar-brand">
            <div className="neo-sidebar-brand-mark">
              <AppIcon name="app_logo_cadeado_carrinho" size={48} className="neo-brand-icon" />
            </div>
            <div className="neo-sidebar-brand-copy">
              <strong>SMART LOJA FACIL</strong>
              <small>{runtimeInfo.isWeb ? 'PWA sincronizado' : 'Store Manager Local'}</small>
            </div>
            <button type="button" className="neo-sidebar-close" onClick={() => setSidebarOpen(false)} aria-label="Fechar menu">×</button>
          </div>

          <nav className="neo-nav" aria-label="Menu principal">
            {pages.map((page) => {
              const pageAlert = navAlerts[page.key];
              return (
                <button
                  type="button"
                  key={page.key}
                  className={`neo-nav-item ${activePage === page.key ? 'active' : ''} ${pageAlert.level ? `is-${pageAlert.level}` : ''}`.trim()}
                  onClick={() => setActivePage(page.key)}
                  aria-current={activePage === page.key ? 'page' : undefined}
                >
                  <span className="neo-nav-item-icon">
                    <AppIcon name={page.icon} size={16} className="app-icon-nav" />
                  </span>
                  <span className="neo-nav-item-label">{page.label}</span>
                  {pageAlert.count > 0 ? <small className={`neo-nav-item-badge ${pageAlert.level}`}>{pageAlert.count}</small> : null}
                </button>
              );
            })}
          </nav>

          <div className="neo-sidebar-footer">
            <div className="neo-env-block">
              <div>
                <small>Ambiente</small>
                <strong>{runtimeInfo.isWeb ? 'Online' : 'Local'}</strong>
              </div>
              <span className="neo-status-dot" />
            </div>
            <div className="neo-version-block">
              <span>Versao {status?.version ?? '1.2.0'}</span>
              <button type="button" onClick={() => setActivePage('audit')}>Ver status do sistema</button>
            </div>
          </div>
        </aside>

        <main className="neo-main">
          <header className="neo-topbar">
            <div className="neo-topbar-mobile-row">
              <button type="button" className="neo-menu-button" onClick={() => setSidebarOpen(true)} aria-label="Abrir menu">
                <span />
                <span />
                <span />
              </button>
              <div className="neo-mobile-branding">
                <AppIcon name="app_logo_cadeado_carrinho" size={24} className="neo-mobile-brand-icon" />
                <div>
                  <strong>Smart Loja Facil</strong>
                  <small>Store Manager</small>
                </div>
              </div>
              <div className="neo-mobile-tools">
                <button type="button" className="neo-notify-btn" onClick={() => setActivePage('audit')} aria-label="Notificacoes">
                  <AppIcon name="auditoria_logs" size={16} className="app-icon-chip" />
                  {notificationCount > 0 ? <span>{notificationCount}</span> : null}
                </button>
              </div>
            </div>

            <div className="neo-header-grid">
              <section className="neo-greeting-surface">
                <div className="neo-greeting-copy">
                  <strong>Ola, Administrador 👋</strong>
                  <span>Bem-vindo(a) ao Smart Loja Facil</span>
                </div>
                <div className="neo-user-pill">
                  <span>{avatarInitials}</span>
                  <i />
                </div>
              </section>

              <section className="neo-action-ribbon" aria-label="Atalhos principais">
                {headerActions.map((item) => (
                  <button
                    type="button"
                    key={item.key}
                    className="neo-action-tile"
                    onClick={() => {
                      if (item.action === 'refresh') {
                        onRefresh();
                        return;
                      }
                      setActivePage(item.action);
                    }}
                  >
                    <span className="neo-action-icon"><AppIcon name={item.icon} size={16} className="app-icon-toolbar" /></span>
                    <span className="neo-action-label-full">{item.label}</span>
                    <span className="neo-action-label-mobile">{item.mobileLabel}</span>
                  </button>
                ))}
              </section>

              <section className="neo-header-status-row">
                <div className="neo-header-chip neo-header-chip-primary">
                  <AppIcon name="offline_local" size={16} className="app-icon-chip" />
                  <span>{runtimeInfo.isWeb ? 'Conexao segura' : 'Modo local'}</span>
                </div>
                <div className="neo-header-chip">
                  <AppIcon name="sqlite_ativo" size={16} className="app-icon-chip" />
                  <span>{runtimeInfo.isWeb ? 'Dados sincronizados' : 'SQLite ativo'}</span>
                </div>
                <div className="neo-header-chip">
                  <AppIcon name="calendario_data" size={16} className="app-icon-chip" />
                  <span>{formatClassicDate()}</span>
                </div>
              </section>
            </div>
          </header>

          {toast ? (
            <button type="button" className={`neo-toast neo-toast-${toast.level}`} onClick={() => setActivePage(toast.page)}>
              <strong>{toast.title}</strong>
              <span>{toast.detail}</span>
            </button>
          ) : null}

          <section className="neo-page-shell">
            <div className="neo-page-meta">
              <div>
                <div className="neo-page-meta-title">
                  <span className="neo-page-meta-icon"><AppIcon name={activePageMeta.icon} size={24} className="app-icon-page" /></span>
                  <h1>{activePageMeta.label}</h1>
                </div>
                <p>{pageSubtitle(activePage)}</p>
              </div>
              <div className="neo-page-meta-status">
                <span className={`neo-mini-chip ${(runtimeInfo.isWeb || status?.offline_ready) ? 'ok' : 'warn'}`}>{environmentLabel}</span>
                <span className={`neo-mini-chip ${(runtimeInfo.isWeb || status?.sqlite_ok) ? 'ok' : 'warn'}`}>{runtimeInfo.isWeb ? 'Dados na nuvem' : status?.sqlite_ok ? 'SQLite ativo' : 'SQLite indisponivel'}</span>
              </div>
            </div>

            {activeAlerts.length > 0 ? (
              <div className={`neo-page-alert neo-page-alert-${activeAlerts[0].level}`}>
                <strong>{activeAlerts[0].title}</strong>
                <span>{activeAlerts[0].detail}</span>
              </div>
            ) : null}

            <div className="neo-page-content">{children}</div>
          </section>
        </main>
      </div>

      <nav className="neo-mobile-dock" aria-label="Navegacao mobile">
        {mobileMainPages.map((page) => (
          <button
            type="button"
            key={page.key}
            className={activePage === page.key ? 'active' : ''}
            onClick={() => setActivePage(page.key)}
            aria-current={activePage === page.key ? 'page' : undefined}
          >
            <AppIcon name={page.icon} size={16} className="app-icon-chip" />
            <span>{page.label}</span>
          </button>
        ))}
        <button type="button" className={isMoreActive ? 'active' : ''} onClick={() => setSidebarOpen(true)} aria-current={isMoreActive ? 'page' : undefined}>
          <AppIcon name="configuracoes" size={16} className="app-icon-chip" />
          <span>Mais</span>
        </button>
      </nav>
    </div>
  );
}
