import React from 'react';
import { WebAuthPanel } from '../components/WebAuthPanel';
import type { PageKey } from '../types';

const pageNames: Record<PageKey, string> = {
  dashboard: 'Painel da Loja',
  customers: 'Clientes',
  products: 'Produtos',
  sales: 'Vendas / PDV',
  cash: 'Caixa',
  credits: 'Crediario',
  orders: 'Pedidos',
  receipts: 'Comprovantes',
  reports: 'Relatorios',
  backup: 'Backup',
  settings: 'Configuracoes',
  audit: 'Auditoria / Logs',
  diagnostics: 'Diagnostico Web',
};

const migrationOrder: Array<{ title: string; detail: string; status: 'done' | 'active' | 'next' }> = [
  { title: 'Runtime separado', detail: 'Web nao tenta abrir SQLite/Tauri direto.', status: 'done' },
  { title: 'Login, loja e papel', detail: 'Supabase Auth, loja ativa e papel carregados no navegador.', status: 'done' },
  { title: 'Clientes, Produtos e Configuracoes', detail: 'Primeiros modulos ligados a camada Supabase web.', status: 'done' },
  { title: 'Vendas, Caixa e Crediario', detail: 'Entram depois com transacoes e protecao contra duplicidade.', status: 'active' },
];

interface WebMigrationPageProps {
  activePage: PageKey;
  onOpenDiagnostics: () => void;
}

export function WebMigrationPage({ activePage, onOpenDiagnostics }: WebMigrationPageProps): JSX.Element {
  const moduleName = pageNames[activePage] ?? 'Modulo';

  return (
    <div className="stack web-stack">
      <section className="web-hero-card web-hero-card-warning">
        <span className="web-kicker">Modulo em migracao</span>
        <h1>{moduleName} ainda aguarda migracao segura</h1>
        <p>No PWA, este modulo fica bloqueado ate entrar no Supabase com transacao, permissao e protecao contra duplicidade. Clientes, Produtos e Configuracoes ja foram liberados para a camada web.</p>
        <div className="web-hero-actions">
          <button type="button" className="primary-btn" onClick={onOpenDiagnostics}>Abrir diagnostico web</button>
          <span className="status-chip">PWA protegido</span>
          <span className="status-chip">Supabase por etapas</span>
        </div>
      </section>

      <div className="web-two-col">
        <section className="web-card">
          <span className="web-kicker">Ordem correta</span>
          <h2>Plano de migracao sem perda de dados</h2>
          <div className="web-timeline">
            {migrationOrder.map((item) => (
              <article key={item.title} className={`web-timeline-item web-timeline-${item.status}`}>
                <strong>{item.title}</strong>
                <small>{item.detail}</small>
              </article>
            ))}
          </div>
        </section>
        <section className="web-card mobile-safe-card">
          <span className="web-kicker">Uso no celular</span>
          <h2>Fluxo seguro por etapas</h2>
          <p>Enquanto este modulo nao estiver no Supabase, o app mostra este bloqueio no mobile para evitar tela branca, dado falso, venda duplicada ou salvamento inseguro.</p>
          <button type="button" className="secondary-btn" onClick={onOpenDiagnostics}>Ver status web</button>
        </section>
        <WebAuthPanel compact />
      </div>
    </div>
  );
}
